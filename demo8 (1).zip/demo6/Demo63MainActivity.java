package com.example.giaodien.demo6;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.giaodien.R;
import com.google.android.material.tabs.TabLayout;

public class Demo63MainActivity extends AppCompatActivity {
    ViewPager viewPager;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo63_main);
        viewPager = findViewById(R.id.demo63_viewPager);
        tabLayout = findViewById(R.id.demo63_tablayout);
        addTablayout(viewPager);
        tabLayout.setupWithViewPager(viewPager);//dua viewPager vao tablayout
    }
    //dinh nghia ham addTabLayout
    public void addTablayout(ViewPager viewPager)
    {
        //tao moi adapter
        Demo63Adapter adapter = new Demo63Adapter(getSupportFragmentManager());
        //them fragment vao Adapter, muc dich: dua fragment vao viewPager
        adapter.addFrag(new Demo63BlankFragment1(),"ONE");
        adapter.addFrag(new Demo63BlankFragment2(),"TWO");
        adapter.addFrag(new Demo63BlankFragment3(),"THREE");
        //dua adapter vao viewPager
        viewPager.setAdapter(adapter);
    }
}
