package com.example.giaodien.demo6;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

import com.example.giaodien.R;


public class Demo62BlankFragment1 extends Fragment {
    EditText txtFra1;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.fragment_demo62_blank1, container, false);
        txtFra1 = view.findViewById(R.id.demo62_fra_txt1);
        return view;
    }
}
