package com.example.giaodien.demo6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.example.giaodien.R;

public class Demo61MainActivity extends AppCompatActivity {
    //Truyen du lieu tu Activity cho Fragment
    Button btnSend;
    EditText txtSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo61_main);
        btnSend = findViewById(R.id.demo61Btn1);
        txtSend = findViewById(R.id.demo61Txt);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //anh xa fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                Demo61BlankFragment fragment =
                        (Demo61BlankFragment)fragmentManager
                                .findFragmentById(R.id.demo61_fragment1);
                //setText cho EditText cua fragment
                fragment.editText.setText(txtSend.getText().toString());
            }
        });
    }
}
