package com.example.giaodien.demo6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.example.giaodien.R;

public class Demo62MainActivity extends AppCompatActivity {
    Button btnAdd, btnRemove;
    Demo62BlankFragment1 fragment1;
    Demo62BlankFragment2 fragment2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //ẩn hiện fragment
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo62_main);
        btnAdd = findViewById(R.id.demo62BtnAdd);
        btnRemove = findViewById(R.id.demo62BtnRemove);
        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //anh xa fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragment1 = (Demo62BlankFragment1)fragmentManager
                        .findFragmentById(R.id.demo62_fragment_1);
                fragment2 = (Demo62BlankFragment2)fragmentManager
                        .findFragmentById(R.id.demo62_fragment_2);
                //an hien fragment
                fragmentManager.beginTransaction()
                        .hide(fragment1)
                        .commit();
                btnAdd.setVisibility(View.VISIBLE);//hiển thị button Add
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //anh xa fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragment1 = (Demo62BlankFragment1)fragmentManager
                        .findFragmentById(R.id.demo62_fragment_1);
                fragment2 = (Demo62BlankFragment2)fragmentManager
                        .findFragmentById(R.id.demo62_fragment_2);
                //an hien fragment
                fragmentManager.beginTransaction()
                        .show(fragment1)
                        .commit();
                btnAdd.setVisibility(View.INVISIBLE);//ẩn button Add
            }
        });
    }
}
