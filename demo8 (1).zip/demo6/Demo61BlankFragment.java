package com.example.giaodien.demo6;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.giaodien.R;


public class Demo61BlankFragment extends Fragment {
   Button button;
   EditText editText;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_demo61_blank, container, false);
        //ánh xạ
        button = view.findViewById(R.id.demo61_fra_btn);
        editText = view.findViewById(R.id.demo61_frg_txt);
        //xu ly su kien
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(),editText.getText(),Toast.LENGTH_LONG).show();
            }
        });
        return view;
    }
}
