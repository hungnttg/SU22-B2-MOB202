package com.example.giaodien.demo8;

public class User83 {
    private String name;
    private int pic;

    public User83(String name, int pic) {
        this.name = name;
        this.pic = pic;
    }

    public User83() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPic() {
        return pic;
    }

    public void setPic(int pic) {
        this.pic = pic;
    }
}
