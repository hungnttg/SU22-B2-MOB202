package com.example.giaodien.demo8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.giaodien.R;

import java.util.List;

public class Demo83Adapter extends RecyclerView.Adapter<Demo83Adapter.UserViewHolder> {
    private List<User83> list;
    private Context context;
    //khoi tao
    public Demo83Adapter(List<User83> list, Context context) {
        this.list = list;
        this.context = context;
    }

    //tao view
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //ket xuat layout
        View view = LayoutInflater.from(context).inflate(R.layout.item_view_83,null);
        return new  UserViewHolder(view);
    }
    //gan du lieu
    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, final int position) {
        holder.textView.setText(list.get(position).getName());
        holder.imageView.setImageResource(list.get(position).getPic());
        //xu ly su kien
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,list.get(position).getName(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    //lay tong so item
    @Override
    public int getItemCount() {
        return list.size();
    }

    //lop anh xa layout
    public static class UserViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textView;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView_83);
            textView = itemView.findViewById(R.id.textView_83);
        }
    }
}
