package com.example.giaodien.demo8;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import com.example.giaodien.R;
import com.example.giaodien.demo6.Demo63Adapter;
import com.example.giaodien.demo6.Demo63BlankFragment1;
import com.example.giaodien.demo6.Demo63BlankFragment2;
import com.example.giaodien.demo6.Demo63BlankFragment3;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;

public class Deno82MainActivity extends AppCompatActivity {
    ViewPager viewPager;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deno82_main);
        DrawerLayout drawerLayout = findViewById(R.id.draw_layout_82);
        NavigationView navigationView = findViewById(R.id.nav_82);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Toast.makeText(getApplicationContext(),item.getTitle(),Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        viewPager = findViewById(R.id.demo82_viewPager);
        tabLayout = findViewById(R.id.demo82_tablayout);
        addTablayout(viewPager);
        tabLayout.setupWithViewPager(viewPager);//dua viewPager vao tablayout
    }
    //dinh nghia ham addTabLayout
    public void addTablayout(ViewPager viewPager)
    {
        //tao moi adapter
        Demo63Adapter adapter = new Demo63Adapter(getSupportFragmentManager());
        //them fragment vao Adapter, muc dich: dua fragment vao viewPager
        adapter.addFrag(new Demo63BlankFragment1(),"ONE");
        adapter.addFrag(new Demo63BlankFragment2(),"TWO");
        adapter.addFrag(new Demo63BlankFragment3(),"THREE");
        //dua adapter vao viewPager
        viewPager.setAdapter(adapter);
    }
}
