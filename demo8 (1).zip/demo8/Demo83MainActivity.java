package com.example.giaodien.demo8;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.giaodien.R;

import java.util.ArrayList;
import java.util.List;

public class Demo83MainActivity extends AppCompatActivity {
    List<User83> list = new ArrayList<>();
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo83_main);
        recyclerView = findViewById(R.id.recyclerview_83);
        //tao layout quan tri recyclerview
        LinearLayoutManager linearLayoutManager
                =new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        //them du lieu vao list
        list.add(new User83("Nguyen Van An",R.mipmap.ic_launcher) );
        list.add(new User83("Tran Van BInh",R.mipmap.ic_launcher) );
        list.add(new User83("Vu Van Cong",R.mipmap.ic_launcher) );
        list.add(new User83("Nguyen Thi Dung",R.mipmap.ic_launcher) );
        list.add(new User83("Truong Van Giang",R.mipmap.ic_launcher) );
        //tao adapter
        Demo83Adapter adapter = new Demo83Adapter(list,this);
        //do du lieu vao recyclerview
        recyclerView.setAdapter(adapter);
    }
}
