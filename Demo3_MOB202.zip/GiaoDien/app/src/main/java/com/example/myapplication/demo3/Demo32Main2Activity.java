package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Demo32Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        listView = findViewById(R.id.demo32Listview);
        //b1. tao layout
        //b2 - tao nguon du lieu
        List<HashMap<String,Object>> list = new ArrayList<>();

        HashMap<String,Object> hm = new HashMap<>();
        hm.put("ten","Hung");
        hm.put("tuoi",18);
        hm.put("hinh",R.drawable.android);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","An");
        hm.put("tuoi",20);
        hm.put("hinh",R.drawable.firefox);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","Binh");
        hm.put("tuoi",22);
        hm.put("hinh",R.drawable.chrome);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","Cong");
        hm.put("tuoi",29);
        hm.put("hinh",R.drawable.apple);
        list.add(hm);
        //b3- Anh xa nguon du lieu
        String[] from = {"ten","tuoi","hinh"};
        int[] to = {R.id.demo32_item_ten,R.id.demo32_item_tuoi,R.id.demo32_item_hinh};
        //b4- Tao simpleAdapter
        SimpleAdapter simpleAdapter
                =new SimpleAdapter(this,list,R.layout.item_view_demo32,from,to);
        //b5. Dua du lieu len listview
        listView.setAdapter(simpleAdapter);
    }
}
