package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo33Main2Activity extends AppCompatActivity {
    ListView listView;
    //b1. Tao nguon du lieu
    String[] lsTen={"Android","Ios","WindowPhone","Symbian"};
    String[] lsTuoi={"1","5","6","2"};
    int[] lsHinh={R.drawable.android,R.drawable.apple,R.drawable.microsoft,R.drawable.blogger};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo33_main2);
        listView = findViewById(R.id.demo33Listview);

        //b4. goi Adapter
        CustomAdapter33 adapter33 = new CustomAdapter33();
        listView.setAdapter(adapter33);

    }
    //b2. Tao lop Anh xa voi item_view_demo32.xml
    public class ViewAnhXa {
        public ImageView imgHinh;
        public TextView tvTen,tvTuoi;
    }
    //b3. tao customAdapter: Tao view - anh xa - Lay du lieu
    class CustomAdapter33 extends BaseAdapter{
        //lay ve so luong item
        @Override
        public int getCount() {
            return lsHinh.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }
        //tao view- Anh xa - Lay du lieu
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewAnhXa vax;
            //neu chua tao view thi can tao view moi
            if(view==null)
            {
                //tao doi tuong anh xa
                vax = new ViewAnhXa();
                //goi doi tuong ket xuat layout
                LayoutInflater layoutInflater = getLayoutInflater();
                //ket xuat
                view = layoutInflater.inflate(R.layout.item_view_demo32,null);
                //anh xa tung thanh phan
                vax.tvTen = view.findViewById(R.id.demo32_item_ten);
                vax.tvTuoi = view.findViewById(R.id.demo32_item_tuoi);
                vax.imgHinh = view.findViewById(R.id.demo32_item_hinh);
                //tao template de lan sau su dung
                view.setTag(vax);

            }
            else //neu da co view, thi lay ra su dung
            {
                vax = (ViewAnhXa)view.getTag();//lay ra tu template co san
            }
            //thuc hien cap nhat du lieu cho tung truong
            vax.imgHinh.setImageResource(lsHinh[i]);
            vax.tvTen.setText(lsTen[i]);
            vax.tvTuoi.setText(lsTuoi[i]);
            //tra ve ket qua
            return view;
        }
    }
}
