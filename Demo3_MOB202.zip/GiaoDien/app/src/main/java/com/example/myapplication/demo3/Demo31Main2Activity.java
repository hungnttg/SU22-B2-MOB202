package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import com.example.myapplication.R;

public class Demo31Main2Activity extends AppCompatActivity {
    Spinner spinner;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main2);
        spinner = findViewById(R.id.demo31Spinner);
        listView = findViewById(R.id.demo31Listview);
        //B1 - Tạo nguồn dữ liệu
        String[] items = {"Lớp 1","Lớp 2","Lớp 3","Lớp 4","Lớp 5"};
        //B2. Tạo Adapter
        ArrayAdapter<String> listviewAdapter
                =new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,items);
        //b3. Đưa dữ liệu lên Listview
        listView.setAdapter(listviewAdapter);
        ///----------------
        ArrayAdapter<String> spinnerAdapter
        =new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);
        spinner.setAdapter(spinnerAdapter);
    }
}
