package com.example.myapplication.demo7;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Demo74Main2Activity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo74_main2);
        bottomNavigationView  =findViewById(R.id.demo74BottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId()==R.id.demo74_menu_item1)
                {
                    Toast.makeText(getApplicationContext(),item.getTitle(),
                            Toast.LENGTH_LONG).show();
                }
                else if(item.getItemId()==R.id.demo74_menu_item2)
                {
                    Toast.makeText(getApplicationContext(),item.getTitle(),
                            Toast.LENGTH_LONG).show();
                }
                else if(item.getItemId()==R.id.demo74_menu_item3)
                {
                    Toast.makeText(getApplicationContext(),item.getTitle(),
                            Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });
    }
}
