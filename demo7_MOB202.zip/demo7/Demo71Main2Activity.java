package com.example.myapplication.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.myapplication.R;
import com.google.android.material.snackbar.Snackbar;

public class Demo71Main2Activity extends AppCompatActivity {
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo71_main2);
        button = findViewById(R.id.demo71Btn1);
    }

    public void snackbar1(View view) {
        Snackbar.make(button,"Thong bao",5000)
                .setActionTextColor(Color.RED)
                .setText("Ban click vao ,,,,")
                .setAction("OK", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                }).show();
    }
}
