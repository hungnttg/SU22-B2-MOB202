package com.example.myapplication.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.myapplication.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Demo73Main2Activity extends AppCompatActivity {
    FloatingActionButton fBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo73_main2);
        fBtn  = findViewById(R.id.demo73floatingActionButton);
        fBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Thong bao...",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
