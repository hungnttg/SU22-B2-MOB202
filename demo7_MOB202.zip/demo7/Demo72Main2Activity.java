package com.example.myapplication.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

public class Demo72Main2Activity extends AppCompatActivity {
    //hungnq@fpt.edu.vn
    TextInputLayout textInputLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo72_main2);
        textInputLayout = findViewById(R.id.demo72TextInputLayout);
    }

    public void login72(View view) {
        if(textInputLayout.getEditText().length()==0)//khong nhap
        {
            textInputLayout.setError("Vui long nhap user");
        }
        else
        {
            textInputLayout.setError("");
        }
    }
}
