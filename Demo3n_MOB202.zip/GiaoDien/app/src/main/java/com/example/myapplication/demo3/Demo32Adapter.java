package com.example.myapplication.demo3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo32Adapter extends BaseAdapter {
    Context context;
    int[] hinh;
    String[] ten;
    String[] tuoi;
    LayoutInflater layoutInflater;//đối tượng vẽ layout
    //ham khoi tao
    public Demo32Adapter(Context context,int[] hinh,String[] ten,String[] tuoi)
    {
        this.context = context;
        this.hinh = hinh;
        this.ten=ten;
        this.tuoi=tuoi;
        layoutInflater = LayoutInflater.from(context);//khởi tạo đối tượng vẽ layout
    }
    //ham tinh tong so item
    @Override
    public int getCount() {
        return hinh.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }
    //tao view + gan du lieu cho view
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //1.vẽ layout
        view = layoutInflater.inflate(R.layout.item_view_demo32,null);
        //2.ánh xạ từng thành phần
        ImageView imgHinh = view.findViewById(R.id.demo32_item_hinh);
        TextView  tvTen = view.findViewById(R.id.demo32_item_ten);
        TextView tvTuoi = view.findViewById(R.id.demo32_item_tuoi);
        //3. gan du lieu cho tung thanh phan
        imgHinh.setImageResource(hinh[i]);
        tvTen.setText(ten[i]);
        tvTuoi.setText(tuoi[i]);
        return view;
    }
}
