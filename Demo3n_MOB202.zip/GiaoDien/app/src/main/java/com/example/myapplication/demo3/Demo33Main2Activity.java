package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.SimpleAdapter;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Demo33Main2Activity extends AppCompatActivity {
    GridView gridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo33_main2);
        gridView = findViewById(R.id.demo33GridView);

        //1.tao nguon du lieu
        List<HashMap<String,Object>> list = new ArrayList<>();

        HashMap<String,Object> hm = new HashMap<>();
        hm.put("hinh",R.drawable.apple);
        hm.put("ten","apple");
        list.add(hm);

        hm = new HashMap<>();
        hm.put("hinh",R.drawable.chrome);
        hm.put("ten","chrome");
        list.add(hm);

        hm = new HashMap<>();
        hm.put("hinh",R.drawable.firefox);
        hm.put("ten","firefox");
        list.add(hm);

        hm = new HashMap<>();
        hm.put("hinh",R.drawable.blogger);
        hm.put("ten","blogger");
        list.add(hm);

        hm = new HashMap<>();
        hm.put("hinh",R.drawable.facebook);
        hm.put("ten","facebook");
        list.add(hm);
        //2. ánh xạ nguồn dữ liệu
        String[] from={"ten","hinh"};
        int[] to = {R.id.demo33_item_view_ten,R.id.demo33_item_view_hinh};
        //3. Tạo adapter
        SimpleAdapter simpleAdapter
                =new SimpleAdapter(this,list,R.layout.item_view_demo33,from,to);
        //4. Đưa dữ liệu lên gridview
        gridView.setAdapter(simpleAdapter);
    }
}
