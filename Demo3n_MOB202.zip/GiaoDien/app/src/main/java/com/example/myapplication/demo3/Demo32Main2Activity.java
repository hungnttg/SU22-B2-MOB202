package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

public class Demo32Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        listView = findViewById(R.id.demo32Listview);
        //B4- Tao nguon du lieu
        int[] hinh={
          R.drawable.blogger,
          R.drawable.microsoft,
          R.drawable.apple,
          R.drawable.android,
          R.drawable.chrome
        };
        String[] ten={
          "blogger","microsoft","apple","android","chrome"
        };
        String[] tuoi={
             "8","6","1","2","9"
        };
        //B5- gọi Adapter
        Demo32Adapter adapter
                =new Demo32Adapter(this,hinh,ten,tuoi);
        //b6. Dua du lieu len listview
        listView.setAdapter(adapter);
    }
}
