package com.example.myapplication.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo21Main2Activity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main2);
        textView = findViewById(R.id.demo21Txt1);
        //copy font chu vao he thong
        Typeface font = Typeface.createFromAsset(getAssets(),"Blazed.ttf");
        //ap dung font chu cho textview
        textView.setTypeface(font);
    }
}
