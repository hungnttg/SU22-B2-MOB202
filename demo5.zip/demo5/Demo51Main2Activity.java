package com.example.myapplication.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import com.example.myapplication.R;

import java.util.Calendar;

public class Demo51Main2Activity extends AppCompatActivity {
    Button btnDate,btnTime;
    TextView tvDate,tvTime;
    Context context = this;
    Calendar calendar = Calendar.getInstance();
    final int gio = calendar.get(Calendar.HOUR_OF_DAY);
    final int phut = calendar.get(Calendar.MINUTE);

    final int day = calendar.get(Calendar.DAY_OF_MONTH);
    final int month = calendar.get(Calendar.MONTH);
    final int year = calendar.get(Calendar.YEAR);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo51_main2);
        btnDate = findViewById(R.id.demo51BtnDate);
        btnTime = findViewById(R.id.demo51BtnTime);
        tvDate = findViewById(R.id.demo51TvDate);
        tvTime = findViewById(R.id.demo51TvTime);
        //xu ly su kien btnDate
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //b1. tao DatePicker
                DatePickerDialog dp = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        //b2: thiet lap ngay thang
                        i1+=1;
                        tvDate.setText(i2+"/"+i1+"/"+i);
                    }
                },day,month,year);
                //b3. hien thi
                dp.show();
            }
        });
        //Xu ly su kien btnTime
        btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //B1. Tao TimePicker
                TimePickerDialog tp = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        //B2. thiet lap thoi gian
                        tvTime.setText(i+":"+i1);
                    }
                },gio,phut,android.text.format.DateFormat.is24HourFormat(context));
                //b3. Hien thi
                tp.show();
            }
        });
    }
}
