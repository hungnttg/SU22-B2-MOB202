package com.example.myapplication.demo5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.R;

public class Demo52Main2Activity extends AppCompatActivity {
    Button btn1,btn2,btn3,btn4,btn5;
    Context context = this;
    ProgressDialog p;
    Handler handler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo52_main2);
        btn1 = findViewById(R.id.demo52Btn1);
        btn2 = findViewById(R.id.demo52Btn2);
        btn3 = findViewById(R.id.demo52Btn3);
        btn4 = findViewById(R.id.demo52Btn4);
        btn5 = findViewById(R.id.demo52Btn5);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p = new ProgressDialog(context);
                p.setTitle("Downloading...");
                p.setMessage("Download in process...");
                p.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                p.setProgress(0);//gia tri khoi tao
                p.setMax(100);//gia tri lon nhat
                p.show();
                //cap nhat tien trinh
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        //khi chua dt 100% thi chat tiep
                        while (p.getProgress()<=p.getMax())
                        {
                            try {
                                //ngu 1s
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            //cap nhat gi tri vao dialog
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    p.incrementProgressBy(5);
                                }
                            });
                            //kiem tra dieu kien thoat
                            if(p.getProgress()==p.getMax())
                            {
                                p.dismiss();
                            }
                        }

                    }
                }).start();
            }
        });
        //AlertDialog
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //b1. Tao builder
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                //b2. them cac thanh phan cho builder
                builder.setTitle("Thong bao");
                builder.setMessage("dmfdkfdkf ndkfndf");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),"Ban chon OK",
                                Toast.LENGTH_LONG).show();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),"Ban chon Cancel",
                                Toast.LENGTH_LONG).show();
                    }
                });
                //b3. Tao dialog
                AlertDialog alertDialog = builder.create();
                //b4. Hien thi dialog
                alertDialog.show();
            }
        });
        //---------------
        //Radiobutton
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //b1. tao nguon du lieu
                final String[] arr = getResources().getStringArray(R.array.color);
                //b2. Tao builder
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                //b3. tao cac thanh phan cho builder
                builder.setTitle("Thong bao");
                builder.setSingleChoiceItems(arr, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),"Ban chon: "+arr[i],
                                Toast.LENGTH_LONG).show();
                    }
                });
                //B4.Tao dialog
                AlertDialog alertDialog = builder.create();
                //B5. hien thi
                alertDialog.show();
            }
        });
        //----------checkbox
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //b1. tao nguon du lieu
                final String[] arr = getResources().getStringArray(R.array.color);
                //b2. Tao builder
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                //b3. tao cac thanh phan cho builder
                builder.setTitle("Thong bao");
                builder.setMultiChoiceItems(arr, null, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                        Toast.makeText(getApplicationContext(),"Ban chon: "+arr[i],
                                Toast.LENGTH_LONG).show();
                    }
                });
                //B4.Tao dialog
                AlertDialog alertDialog = builder.create();
                //B5. hien thi
                alertDialog.show();
            }
        });
        //---------form
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //b2. Tao builder
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                //b3. tao cac thanh phan cho builder
                LayoutInflater inflater = getLayoutInflater();//doi tuong ve layout
                View view1 = inflater.inflate(R.layout.demo52_login,null);
                final EditText txtUser = view1.findViewById(R.id.demo52_item_txt1);
                final EditText txtpass = view1.findViewById(R.id.demo52_item_txt2);
                builder.setView(view1);
                builder.setTitle("Login");
                builder.setPositiveButton("Login", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Xin chao "+txtUser.getText().toString(),Toast.LENGTH_LONG).show();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                //B4.Tao dialog
                AlertDialog alertDialog = builder.create();
                //B5. hien thi
                alertDialog.show();
            }
        });
    }
}
