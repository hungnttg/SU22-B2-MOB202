package com.example.myapplication.demo6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Demo61Main2Activity extends AppCompatActivity {
    //6.1.truyen text tu Activity vao Fragment
    Button btn1;
    EditText txt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo61_main2);
        btn1 = findViewById(R.id.demo61Btn1);
        txt1 = findViewById(R.id.demo61Txt1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Anh xa fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                Demo61BlankFragment fragment
                 =(Demo61BlankFragment)fragmentManager.findFragmentById(R.id.demo61fragment);
                //set Text for editText of Fragment
                //nghia la truyen text tu Activity vao Fragment
                fragment.editText.setText(txt1.getText().toString());
            }
        });
    }
}
