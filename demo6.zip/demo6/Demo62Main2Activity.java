package com.example.myapplication.demo6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.myapplication.R;

public class Demo62Main2Activity extends AppCompatActivity {
    Button btnAdd,btnRemove;
    Demo62BlankFragment1 fragment1;
    Demo62BlankFragment2 fragment2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo62_main2);
        btnAdd = findViewById(R.id.demo62Add);
        btnRemove = findViewById(R.id.demo62Remove);
        btnAdd.setVisibility(View.INVISIBLE);
        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Anh xa fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragment1 =
                (Demo62BlankFragment1)fragmentManager.findFragmentById(R.id.demo62fragment1);
                fragment2 =
                (Demo62BlankFragment2)fragmentManager.findFragmentById(R.id.demo62fragment2);
                //an fragment
                fragmentManager.beginTransaction()
                        .hide(fragment1)
                        .commit();
                btnAdd.setVisibility(View.VISIBLE);//hien thi button Add
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Anh xa fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragment1 =
                        (Demo62BlankFragment1)fragmentManager.findFragmentById(R.id.demo62fragment1);
                fragment2 =
                        (Demo62BlankFragment2)fragmentManager.findFragmentById(R.id.demo62fragment2);
                //an fragment
                fragmentManager.beginTransaction()
                        .show(fragment1)
                        .commit();
                btnAdd.setVisibility(View.INVISIBLE);
            }
        });
    }
}
