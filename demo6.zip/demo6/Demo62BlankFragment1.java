package com.example.myapplication.demo6;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.example.myapplication.R;


public class Demo62BlankFragment1 extends Fragment {

    EditText demo62txt1Fra1;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_demo62_blank1, container, false);
        demo62txt1Fra1 = view.findViewById(R.id.demo62_fra1_txt1);
        return view;
    }
}
