package com.example.myapplication.demo6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.example.myapplication.R;
import com.google.android.material.tabs.TabLayout;

public class Demo63Main2Activity extends AppCompatActivity {
    ViewPager viewPager;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo63_main2);
        viewPager = findViewById(R.id.demo63_viewPager);
        tabLayout = findViewById(R.id.demo63_tablayout);
        addTabLayout(viewPager);
        tabLayout.setupWithViewPager(viewPager);//dua viewPage vao tablayout
    }
    public void addTabLayout(ViewPager viewPager)
    {
        Demo63Adapter adapter = new Demo63Adapter(getSupportFragmentManager());
        //dua fragment vao adapter
        adapter.addTab(new Demo61BlankFragment(),"ONE");
        adapter.addTab(new Demo62BlankFragment1(),"TWO");
        adapter.addTab(new Demo62BlankFragment2(),"THREE");
        viewPager.setAdapter(adapter);
    }
}
