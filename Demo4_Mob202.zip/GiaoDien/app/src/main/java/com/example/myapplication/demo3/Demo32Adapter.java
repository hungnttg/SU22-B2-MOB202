package com.example.myapplication.demo3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo32Adapter extends BaseAdapter {
    LayoutInflater layoutInflater;// thành phần vẽ layout
    Context context;
    int[] hinh;
    String[] ten;
    //hàm khởi tạo
    public Demo32Adapter(Context context, int[] hinh, String[] ten) {
        this.context = context;
        this.hinh = hinh;
        this.ten = ten;
        layoutInflater = LayoutInflater.from(context);//khởi tạo đối tượng vẽ layout
    }

    //Tong so item
    @Override
    public int getCount() {
        return hinh.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }
    //Tao view và gán dữ liệu cho view
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //vẽ layout
        view = layoutInflater.inflate(R.layout.demo32_item_view,null);
        //ánh xạ từng thành phần
        ImageView imgHinh = view.findViewById(R.id.demo32_item_hinh);
        TextView tvTen = view.findViewById(R.id.demo32_item_ten);
        //đưa dữ liệu vào các thành phần
        imgHinh.setImageResource(hinh[i]);
        tvTen.setText(ten[i]);
        return view;
    }
}
