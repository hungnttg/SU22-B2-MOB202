package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;

import com.example.myapplication.R;

public class Demo32Main2Activity extends AppCompatActivity {
    GridView gridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        gridView = findViewById(R.id.demo32Gridview);
        //Nguồn dữ liệu cho Hình
        int[]hinh ={
          R.drawable.apple,
          R.drawable.android,
          R.drawable.facebook,
          R.drawable.blogger,
          R.drawable.dell
        };
        //Nguồn dữ liệu cho Tên
        String[] ten={"apple","android","facebook","blogger","dell"};
        //Gọi Adapter
        Demo32Adapter adapter
                =new Demo32Adapter(this,hinh,ten);
        //đưa dữ liệu lên gridview
        gridView.setAdapter(adapter);
    }
}
