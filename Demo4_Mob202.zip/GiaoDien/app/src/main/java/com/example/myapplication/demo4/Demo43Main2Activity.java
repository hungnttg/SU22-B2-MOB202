package com.example.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;

public class Demo43Main2Activity extends AppCompatActivity {
    Button btn;
    TextView tv;
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo43_main2);
        btn = findViewById(R.id.demo43Btn);
        tv = findViewById(R.id.demo43Tv);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //b1 - Tao menu
                //b2- gan vao textview
                PopupMenu popupMenu
                        =new PopupMenu(context,tv);
                //ve layout
                MenuInflater inflater
                        =(MenuInflater)popupMenu.getMenuInflater();
                inflater.inflate(R.menu.demo42_menu,popupMenu.getMenu());
                //hien thi
                popupMenu.show();
                //xu ly su kien
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        if(menuItem.getItemId()==R.id.demo42_item1)
                        {
                            Toast.makeText(context,menuItem.getTitle(),Toast.LENGTH_LONG).show();
                        }
                        else if(menuItem.getItemId()==R.id.demo42_item2)
                        {
                            Toast.makeText(context,menuItem.getTitle(),Toast.LENGTH_LONG).show();
                        }
                        else if(menuItem.getItemId()==R.id.demo42_item3)
                        {
                            Toast.makeText(context,menuItem.getTitle(),Toast.LENGTH_LONG).show();
                        }
                        return false;
                    }
                });
            }
        });
    }
}
