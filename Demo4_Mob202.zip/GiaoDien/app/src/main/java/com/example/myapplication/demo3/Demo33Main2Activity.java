package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Demo33Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo33_main2);
        listView = findViewById(R.id.demo33Listview);
        //B1, Tạo nguồn dữ liệu
        List<HashMap<String,Object>> list = new ArrayList<>();

        HashMap<String,Object> hm = new HashMap<>();
        hm.put("ten","Nguyen Van An");
        hm.put("hinh",R.drawable.facebook);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","TRan van Ben");
        hm.put("hinh",R.drawable.apple);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","Vu Van Cong");
        hm.put("hinh",R.drawable.firefox);
        list.add(hm);
        //B2.Tạo Ánh xạ nguồn dữ liệu
        String[] from = {"ten","hinh"};
        int[] to = {R.id.demo33_item_ten,R.id.demo33_item_hinh};
        //B3. Tạo adapter
        SimpleAdapter simpleAdapter
                =new SimpleAdapter(this,list,R.layout.demo33_item_view,from,to);
        //b4. Dua du lieu len listview
        listView.setAdapter(simpleAdapter);
    }
}
