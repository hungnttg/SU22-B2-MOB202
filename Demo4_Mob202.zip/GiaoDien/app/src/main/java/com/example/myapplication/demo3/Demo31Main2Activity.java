package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import com.example.myapplication.R;

public class Demo31Main2Activity extends AppCompatActivity {
    Spinner spinner;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main2);
        spinner = findViewById(R.id.demo31Spinner);
        listView = findViewById(R.id.demo31Listview);
        //b1 -  Tạo nguồn dữ liệu
        String[] data = {"Lop 1","Lop 2","Lop 3","Lop 4"};
        //b2- tạo Adapter
        ArrayAdapter<String> adapter
         =new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
                data);
        //b3 - đưa dữ liệu lên Spinner
        spinner.setAdapter(adapter);
        //--------------
        ArrayAdapter<String>
                adapter1=new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,data);
        listView.setAdapter(adapter1);

    }
}
