package com.example.myapplication.demo4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.myapplication.R;

public class Demo42OptionMain2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo42_option_main2);
    }
    //ham tao menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.demo42_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    //ham xu ly su kien cua menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.demo42_item1)
        {
            Toast.makeText(this,item.getTitle(),Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.demo42_item2)
        {
            Toast.makeText(this,item.getTitle(),Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.demo42_item3)
        {
            Toast.makeText(this,item.getTitle(),Toast.LENGTH_LONG).show();
        }

        return super.onOptionsItemSelected(item);
    }
}
