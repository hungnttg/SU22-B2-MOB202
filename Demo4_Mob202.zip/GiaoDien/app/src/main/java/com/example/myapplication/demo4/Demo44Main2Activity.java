package com.example.myapplication.demo4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.R;

public class Demo44Main2Activity extends AppCompatActivity {
    ListView listView;
    String[] arr = new String[]{"Cam","Xoai","Dua","Coc","oi"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo44_main2);
        listView = findViewById(R.id.demo44Listview);
        ArrayAdapter<String> adapter
                =new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arr);
        listView.setAdapter(adapter);
        registerForContextMenu(listView);//dang ky menu long click
    }
    //ham tao menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
       getMenuInflater().inflate(R.menu.demo42_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }
    //ham xu ly su kien
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info
                =(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int vitri = info.position;
        if(item.getItemId()==R.id.demo42_item1)
        {
            Toast.makeText(this,"Vitri: "+arr[vitri]+" - "+ item.getTitle(),Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.demo42_item2)
        {
            Toast.makeText(this,"Vitri: "+arr[vitri]+" - "+item.getTitle(),Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.demo42_item3)
        {
            Toast.makeText(this,"Vitri: "+arr[vitri]+" - "+item.getTitle(),Toast.LENGTH_LONG).show();
        }
        return super.onContextItemSelected(item);
    }
}
